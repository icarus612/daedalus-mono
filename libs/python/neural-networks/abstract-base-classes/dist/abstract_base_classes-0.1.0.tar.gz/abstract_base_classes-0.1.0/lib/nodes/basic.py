

class Basic:
	def __init__(): 
		pass