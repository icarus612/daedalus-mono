from ANN import ANN_Shell

class MLP_Shell(ANN_Shell):
	def __init__(self):
		super().__init__()
		self.input_layer = None
		self.hidden_layers = []
		self.output_layer = None

	def forward(self, x):
		pass

	def backward(self, y):
		pass

	def train(self):
		pass

	def create_input_layer(self):
		pass

	def create_hidden_layers(self):
		pass

	def create_output_layer(self):
		pass
	

  